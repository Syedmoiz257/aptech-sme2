/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sessionnew;

import java.util.Scanner;

/**
 *
 * @author Student
 */
public class calculator {
    // method to add two integers
    
    public void add(int num1, int num2 ){
         int num3;
         num3= num1 + num2;
         System.out.println("result after addition is " + num3);
        
    }
    // method to subtract two integers
    public void sub(int num4, int num5 ){
         int num3;
         num3= num4 - num5;
         System.out.println("result after a is subtraction " + num3);
        
    }
    // method to multiply two integers
    public void mul(int num6, int num7 ){
         int num3;
         num3= num6 * num7;
         System.out.println("result after a is multiplication " + num3);
        
    }
    // method to divide two integers
    public void div(float num8, float num9 ){
         float num3;
         num3= num8 / num9;
         System.out.println("result after a is division " + num3);
        
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        calculator objcalc =  new calculator();
        
        Scanner sc = new Scanner(System.in);
        //int num1 = sc.nextInt();
       // int num2 = sc.nextInt();
       // int num4 = sc.nextInt();
       // int num5 = sc.nextInt();
        int num6 = sc.nextInt();
        int num7 = sc.nextInt();
       // int num8 = sc.nextInt();
       // int num9 = sc.nextInt();
       
       


// invoke the method with appropiate argument 
        //objcalc.add(num1, num2);
        //objcalc.mul(num4, num5);
        objcalc.div(num6, num7);
       // objcalc.sub(num8, num9);
        
        
    }
    
}
