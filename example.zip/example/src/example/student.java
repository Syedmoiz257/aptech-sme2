/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package example;

/**
 *
 * @author Student
 */
public class student {

   int rollNo;
   String name;
   String address;
   float marks;

public student(){
    rollNo = 0;
    name = "";
    address = "";
    marks = 0;

}
 public student(int rNo, String sname){
 
       rollNo = rNo;
       name = sname;
 
 }
 
 public student(int rNo, float score){
     rollNo = rNo;
     marks = score;
    
 }
 public student(String sname,  String addr){
     name=sname;
     address=addr;
 
 }
 public student(int rNo, String sname, float score){
     
 }
 public void displaydetails(){
    System.out.println("RollNo:"+ rollNo);
    System.out.println("student name"+ name);
    System.out.println("address"+ address);
    System.out.println("score"+ address);
    System.out.println("-----------------");
 
 
 }
 
    public static void main(String[] args) {
        student obj= new student();
        obj.displaydetails();
        
    }

}

  
   
