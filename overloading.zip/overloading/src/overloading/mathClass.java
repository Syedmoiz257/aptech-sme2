/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package overloading;

/**
 *
 * @author Student
 */
public class mathClass {

    public void add(int num1, int num2){
    
        System.out.println("result after addition is"+ num1+num2);
    }
    
    public void add(int num1, int num2, int num3){
        
        System.out.println("result after addition is"+ num1+num2+num3);
    
    } 
    public void add(float num1, int num2){
        
        System.out.println("result after addition is"+ num1+num2);
    }
     
    public void add(int num1, float num2){
        
        System.out.println("result after addition is"+ num1+num2);
  
    }
    public void add(float num1, float num2){
        
        System.out.println("result after addition is"+ num1+num2);
    }
  
    
    public static void main(String[] args) {
        // TODO code application logic here
    mathClass objmath = new mathClass();
    
    // invoke the overloading method with relevant arguments
    objmath.add(1,2);
    objmath.add(1,2,3);
    objmath.add(1.5F,2);
    objmath.add(1,2.7F);
    objmath.add(1.8F,2.8F);
    
    
    
    }
    
}
