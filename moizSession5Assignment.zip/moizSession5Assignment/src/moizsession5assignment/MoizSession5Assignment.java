/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package moizsession5assignment;

import java.util.Scanner;

/**
 *
 * @author Muhammad Shiraz
 */
public class MoizSession5Assignment {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    
        Scanner sc = new Scanner(System.in);
        int point= 0,answers,exit;
       
        
        System.out.print("The university is introducing the IQ testing system for its students ");
        System.out.println("The IQ test will test the students on four different kind of following subjects : ");
        System.out.println(" 1- Aptitude \n 2- English \n 3- Mathematics \n 4- Gernel Knowledge ");
        System.out.println(" This test is only those who is attempting this test for the first time ");
        System.out.println(" Press 1 for Yes for taking this test first time \n  otherwise press 2 for No ");
        
        int attempt= sc.nextInt();
        if(attempt== 1){
            System.out.println("These are the four subjects and the best is that you have to attempt only one subject at a time.");
            System.out.println(" 1- Aptitude \n 2- English \n 3- Mathematics \n 4- Gernel Knowledge");
            System.out.println("if u dont want attempt this test just simply press 5-exit ");
            exit = sc.nextInt();
            
            if (exit== 1){
                System.out.println("You chosse Apptitude test");
                System.out.println("question1 \n press 1 for true \n press 2 for false ");
                answers = sc.nextInt();
                switch(answers){
                    case 1:
                    point = point + 10;
                    break;    
                    case 2:
                    point= point + 0;
                    break;    
                    
                        
                    } 
                System.out.println("question2 \n press 1 for true \n press 2 for false ");
                answers = sc.nextInt();
                switch(answers){
                    case 1:
                    point = point + 10;
                    break;    
                    case 2:
                    point= point + 0;
                    break;    
                }
                System.out.println("question3 \n press 1 for true \n press 2 for false ");
                answers = sc.nextInt();
                switch(answers){
                    case 1:
                    point = point + 10;
                    break;    
                    case 2:
                    point= point + 0;
                    break;    
                }
                System.out.println("question4 \n press 1 for true \n press 2 for false ");
                answers = sc.nextInt();
                switch(answers){
                    case 1:
                    point = point + 10;
                    break;    
                    case 2:
                    point= point + 0;
                    break;   
                        
                }
                System.out.println("test completed now press 5-exit and your will be get your result");
                exit = sc.nextInt();
                switch(exit){
                    case 5:
                
                        if(point==40){
                           point = point + 10;
                            System.out.println("yours marks is = "+ point);
                            System.out.println("Your are genius");

                        }
                        else if(point ==30){
                            point = point + 5;
                            System.out.println("your marks is = "+ point);
                            System.out.println("you are intelligent");

                        }
                        else if(point== 20){
                             point = point + 2;
                            System.out.println("your mark is ="+ point);
                            System.out.println("your IQ level is average");

                        }
                        else if(point==10){
                        point= point+0;
                            System.out.println("your mark is ="+point);
                            System.out.println("your IQ level is below average");


                        }
                        else {
                            System.out.println("you need to re-appear the test");
                        }
                    break;
                        default:
                            System.out.println("you press the wrong button");

                           
                }
            } 
        
            
            else if(exit==2 ){
                System.out.println("You chosse english test");
                System.out.println("question1 \n press 1 for true \n press 2 for false ");
                answers = sc.nextInt();
                switch(answers){
                    case 1:
                    point = point + 10;
                    break;    
                    case 2:
                    point= point + 0;
                    break;    
                    
                        
                    } 
                System.out.println("question2 \n press 1 for true \n press 2 for false ");
                answers = sc.nextInt();
                switch(answers){
                    case 1:
                    point = point + 10;
                    break;    
                    case 2:
                    point= point + 0;
                    break;    
                }
                System.out.println("question3 \n press 1 for true \n press 2 for false ");
                answers = sc.nextInt();
                switch(answers){
                    case 1:
                    point = point + 10;
                    break;    
                    case 2:
                    point= point + 0;
                    break;    
                }
                System.out.println("question4 \n press 1 for true \n press 2 for false ");
                answers = sc.nextInt();
                switch(answers){
                    case 1:
                    point = point + 10;
                    break;    
                    case 2:
                    point= point + 0;
                    break;   
                        
                }
                System.out.println("test completed now press 5-exit and your will be get your result");
                exit = sc.nextInt();
                switch(exit){
                    case 5:
                
                        if(point==40){
                           point = point + 10;
                            System.out.println("yours marks is = "+ point);
                            System.out.println("Your are genius");

                        }
                        else if(point ==30){
                            point = point + 5;
                            System.out.println("your marks is = "+ point);
                            System.out.println("you are intelligent");

                        }
                        else if(point== 20){
                             point = point + 2;
                            System.out.println("your mark is ="+ point);
                            System.out.println("your IQ level is average");

                        }
                        else if(point==10){
                        point= point+0;
                            System.out.println("your mark is ="+point);
                            System.out.println("your IQ level is below average");


                        }
                        else {
                            System.out.println("you need to re-appear the test");
                        }
                    break;
                        default:
                            System.out.println("you press the wrong button");

                           
                }
            }
            else if(exit==3 ){
                System.out.println("You chosse Maths test");
                System.out.println("question1 \n press 1 for true \n press 2 for false ");
                answers = sc.nextInt();
                switch(answers){
                    case 1:
                    point = point + 10;
                    break;    
                    case 2:
                    point= point + 0;
                    break;    
                    
                        
                    } 
                System.out.println("question2 \n press 1 for true \n press 2 for false ");
                answers = sc.nextInt();
                switch(answers){
                    case 1:
                    point = point + 10;
                    break;    
                    case 2:
                    point= point + 0;
                    break;    
                }
                System.out.println("question3 \n press 1 for true \n press 2 for false ");
                answers = sc.nextInt();
                switch(answers){
                    case 1:
                    point = point + 10;
                    break;    
                    case 2:
                    point= point + 0;
                    break;    
                }
                System.out.println("question4 \n press 1 for true \n press 2 for false ");
                answers = sc.nextInt();
                switch(answers){
                    case 1:
                    point = point + 10;
                    break;    
                    case 2:
                    point= point + 0;
                    break;   
                        
                }
                System.out.println("test completed now press 5-exit and your will be get your result");
                exit = sc.nextInt();
                switch(exit){
                    case 5:
                
                        if(point==40){
                           point = point + 10;
                            System.out.println("yours marks is = "+ point);
                            System.out.println("Your are genius");

                        }
                        else if(point ==30){
                            point = point + 5;
                            System.out.println("your marks is = "+ point);
                            System.out.println("you are intelligent");

                        }
                        else if(point== 20){
                             point = point + 2;
                            System.out.println("your mark is ="+ point);
                            System.out.println("your IQ level is average");

                        }
                        else if(point==10){
                        point= point+0;
                            System.out.println("your mark is ="+point);
                            System.out.println("your IQ level is below average");


                        }
                        else {
                            System.out.println("you need to re-appear the test");
                        }
                    break;
                        default:
                            System.out.println("you press the wrong button");

                           
                }
                        
            }
            else if(exit==4 ){
                System.out.println("You chosse GK test");
                System.out.println("question1 \n press 1 for true \n press 2 for false ");
                answers = sc.nextInt();
                switch(answers){
                    case 1:
                    point = point + 10;
                    break;    
                    case 2:
                    point= point + 0;
                    break;    
                    
                        
                    } 
                System.out.println("question2 \n press 1 for true \n press 2 for false ");
                answers = sc.nextInt();
                switch(answers){
                    case 1:
                    point = point + 10;
                    break;    
                    case 2:
                    point= point + 0;
                    break;    
                }
                System.out.println("question3 \n press 1 for true \n press 2 for false ");
                answers = sc.nextInt();
                switch(answers){
                    case 1:
                    point = point + 10;
                    break;    
                    case 2:
                    point= point + 0;
                    break;    
                }
                System.out.println("question4 \n press 1 for true \n press 2 for false ");
                answers = sc.nextInt();
                switch(answers){
                    case 1:
                    point = point + 10;
                    break;    
                    case 2:
                    point= point + 0;
                    break;   
                        
                }
                System.out.println("test completed now press 5-exit and your will be get your result");
                exit = sc.nextInt();
                switch(exit){
                    case 5:
                
                        if(point==40){
                           point = point + 10;
                            System.out.println("yours marks is = "+ point);
                            System.out.println("Your are genius");

                        }
                        else if(point ==30){
                            point = point + 5;
                            System.out.println("your marks is = "+ point);
                            System.out.println("you are intelligent");

                        }
                        else if(point== 20){
                             point = point + 2;
                            System.out.println("your mark is ="+ point);
                            System.out.println("your IQ level is average");

                        }
                        else if(point==10){
                        point= point+0;
                            System.out.println("your mark is ="+point);
                            System.out.println("your IQ level is below average");


                        }
                        else {
                            System.out.println("you need to re-appear the test");
                        }
                    break;
                        default:
                            System.out.println("you press the wrong button");

                           
                }
            
            }    

        }
        
        
        else{
        System.err.println("Your are not eligible for this test!");
        System.exit(0);
                
        }
    
    
    
    
    }
    
    }
    

