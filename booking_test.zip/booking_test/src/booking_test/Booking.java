/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package booking_test;

import java.util.Scanner;

/**
 *
 * @author Student
 */
public class Booking {

    /**
     * @param args the command line arguments
     */
    int bookingID,numberOfTickets,date;
    String cabin;
    int price,totalprice;
    String  destination;

    public Booking(int ID, int Tickits, int dates, String cabin_type, String your_destination) {
        this.bookingID = ID;
        this.numberOfTickets = Tickits;
        this.date = dates;
        this.cabin = cabin_type;
        this.destination = your_destination;
    }
    
    void totalprice(){
        totalprice = price * numberOfTickets;
    }
    
    void tickitsconformation(){
        System.out.println("\n\nCustomer BookingID: " + bookingID);
        System.out.println("Number Of Tickits: " + numberOfTickets);
        System.out.println("Depatures Date: " + date);
        System.out.println("Cabin Types: " + cabin);
        System.out.println("Price: " + price);
        System.out.println("Destination: " + destination);
        System.out.println("Total Price: " + totalprice);
    }
    
}
