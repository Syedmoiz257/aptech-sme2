/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package booking_test;

import java.util.Scanner;

/**
 *
 * @author Student
 */
public class test {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int ID,Tickets,dates;
        String cabin_type;
        int tickit_price;
        String your_destination;
        int total_price;
        
        System.out.println("Enter your booking ID:");
        ID = sc.nextInt();
        System.out.println("Enter your No.of tickits:");
        Tickets = sc.nextInt();
        System.out.println("Enter your depature date:");
        dates = sc.nextInt();
        System.out.println("Enter your cabin type: \n \t1.A \t2.B \t3.C");
        cabin_type = sc.next();
        System.out.println("select your destination: \n \t 1.tokyo  \t2.singapore");
        your_destination = sc.next();
        
        
        Booking objbook = new Booking(ID, Tickets, dates, cabin_type, your_destination);
        
        objbook.totalprice();
        
        objbook.tickitsconformation();
    }
}
