/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session_5;

import java.util.Scanner;

/**
 *
 * @author Student
 */
public class assignment {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("WELCOME TO HOWELL UNIVERSITY FOR IQ TEST");
        System.out.println("WE HAVE FOUR KIND OF TEST FOR IQ \n \t 1. APPTITUDE  \n \t 2.ENGLISH \n \t 3. MATHS  \n \t 4.GK");
        System.out.println("IF U ARE NOT INTERESTED PRESS 5.EXIT");
        System.out.println("HOW MANY SUBJECTS YOU WANT'S TO ATTENPT");
        
       int attempt= sc.nextInt();
       if(attempt==1){
           System.out.println("PRESS 1.APPTITUDE  \nPRESS 2.ENGLISH \nPRESS 3.MATHS  \nPRESS 4.GK");
           
           
           
       }   else if(attempt==2){
           System.out.println("PRESS 1.APPTITUDE  \nPRESS 2.ENGLISH \nPRESS 3.MATHS  \nPRESS 4.GK");
           
           
           
       }
       